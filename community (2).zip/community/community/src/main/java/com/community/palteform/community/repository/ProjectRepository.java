package com.community.palteform.community.repository;

import org.springframework.data.repository.CrudRepository;

import com.community.palteform.community.entity.Project;

public interface ProjectRepository extends CrudRepository<Project, Long> {

}
