package com.community.palteform.community.vo;

public class ProjectVO {

}
