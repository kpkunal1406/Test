package com.community.palteform.community.repository;

import org.springframework.data.repository.CrudRepository;

import com.community.palteform.community.entity.Authority;

public interface AuthorityRepository extends CrudRepository<Authority, Long> {

}
