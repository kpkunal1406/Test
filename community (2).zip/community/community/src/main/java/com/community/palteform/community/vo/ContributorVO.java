package com.community.palteform.community.vo;

public class ContributorVO {

	private int contributorId;

	private String name;

	private String type;

	public int getContributorId() {
		return contributorId;
	}

	public void setContributorId(int contributorId) {
		this.contributorId = contributorId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
