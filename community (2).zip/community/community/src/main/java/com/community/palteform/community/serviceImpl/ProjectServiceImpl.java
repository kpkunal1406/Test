package com.community.palteform.community.serviceImpl;

import org.springframework.stereotype.Service;

import com.community.palteform.community.service.ProjectService;

@Service
public class ProjectServiceImpl implements ProjectService {

}
