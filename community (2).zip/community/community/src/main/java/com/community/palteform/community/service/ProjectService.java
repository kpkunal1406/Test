package com.community.palteform.community.service;

public interface ProjectService {

}
