package com.community.palteform.community.repository;

import org.springframework.data.repository.CrudRepository;

import com.community.palteform.community.entity.Contributor;

public interface ContributorRepository extends CrudRepository<Contributor, Long> {

}
